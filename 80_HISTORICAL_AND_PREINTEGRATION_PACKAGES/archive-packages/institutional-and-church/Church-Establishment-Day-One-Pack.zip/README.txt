CHURCH ESTABLISHMENT PROGRAM - DAY ONE PACK

Entity placeholder: [[CORP_NAME]]
Jurisdiction: Tennessee
Model: Nonprofit public benefit religious corporation; no statutory corporate members.

CONTENTS
1. CEP-Day-One-Execution-Binder.docx
   - Master CH-001..CH-054 index
   - CH-001 charter draft and audit
   - CH-002 purpose clause
   - CH-003 dissolution clause
   - CH-004 EIN worksheet
   - CH-005/006 adoption crosswalks
   - CH-007 working foundational beliefs
   - ORG-001 organizational minutes/resolutions
   - OPS-001 records repository plan
   - OPS-002 accounting/banking plan
   - CON-001 congregation/location plan
   - GATE-A-001 readiness review

2. CH-005-Civil-Bylaws-BYL-001.docx
   Full prior civil bylaws, preserved and converted to Word.

3. CH-006-Ecclesiastical-Governance-ECC-CON-001.docx
   Full prior ecclesiastical constitution, preserved and converted to Word.

4. Church-Operations-Registers.xlsx
   Operational workbook: document register, membership, attendance, service records, transactions, donations, restricted funds, budget, bank reconciliation, related parties, compliance calendar.

IMPORTANT
This pack is a working governance/formation package. Complete all [[PLACEHOLDERS]], confirm current filing facts, and obtain Tennessee legal/tax review before filing or formal adoption.
