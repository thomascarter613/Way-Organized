# The Way - Theological Research & Library of Witnesses v0.8

**Release date:** September 19, 2026

## Publications
- `theological_research_method_and_library_of_witnesses_v0_8.docx/pdf`
- `foundational_theology_research_dossiers_volume_i_v0_8.docx/pdf`
- `provisional_theological_baseline_v0_8.docx/pdf`

## Structured sources
- `source/library_of_witnesses_register_v0_8.csv`
- `source/research_claims_register_v0_8.csv`
- `source/provisional_theological_baseline_v0_8.csv`
- `source/theological_research_v0_8.json`
- modular Markdown dossiers and source notes

## Core boundary
This release creates research baselines, not an infallible creed or closed canon. Open questions remain open until evidence and a lawful teaching/doctrine process warrant a change.
