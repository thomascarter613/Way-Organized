# Provisional Theological Baseline v0.8

- **BT-001 - Ultimate reality (Established):** Religious traditions make materially different claims about God/ultimate reality; the Way must not erase those differences.
- **BT-002 - God-language (Provisional):** Companions and Houses may pray using ordinary God-language; the Assembly has not fixed a comprehensive metaphysical doctrine of God.
- **BT-003 - Revelation method (Established):** A revelation claim is testimony requiring evaluation; intensity, office, charisma, or sincerity does not itself establish divine origin.
- **BT-004 - Revelation authority (Established):** No claimed revelation overrides consent, safeguarding, civil law, financial controls, or governing documents.
- **BT-005 - Jesus - history (Established):** Jesus was a first-century Jewish figure whose movement continued after his crucifixion under Pontius Pilate.
- **BT-006 - Jesus - identity (Open Question):** Incarnation, ontological divine sonship, Trinity, atonement mechanisms, and resurrection metaphysics are not yet Assembly doctrine.
- **BT-007 - Muhammad - history (Established):** Muhammad was a seventh-century Arabian religious/political leader; the Qur'an is the earliest principal textual witness to his proclamation.
- **BT-008 - Muhammad - revelation/finality (Open Question):** Divine authorship of the Qur'an and finality of prophethood are studied seriously but are not yet Assembly doctrine.
- **BT-009 - Buddha - history/teaching (Established):** A historical Gautama stands behind Buddhism; early teaching centers liberation from suffering through disciplined ethical and contemplative practice.
- **BT-010 - Buddha - metaphysics (Open Question):** Rebirth, karma across lives, nirvana's metaphysical nature, and the ultimate implications of non-self remain open.
- **BT-011 - Scripture (Established):** The Assembly presently maintains a Library of Witnesses rather than a closed canon.
- **BT-012 - Library inclusion (Established):** Inclusion signifies relevance for study, not inspiration, infallibility, or total endorsement.
- **BT-013 - Human dignity (Established):** Human dignity and conscience do not depend on membership, office, purity status, wealth, sex, belief certainty, or loyalty to the institution.
- **BT-014 - Human fallibility (Established):** All people, including founders and ministers, are vulnerable to bias, self-deception, harmful desire, and social influence; governance must assume fallibility.
- **BT-015 - Human transformation (Well-Supported):** Attention, honesty, compassion, restraint, study, service, relationship, and repair are defensible formation goals across multiple anthropological models.
- **BT-016 - Soul / afterlife (Open Question):** Immortal soul, resurrection, rebirth, postmortem consciousness, and related mechanisms remain unresolved.