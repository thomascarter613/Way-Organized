# v0.7 Theology, Practice & Formation Architecture

**Version:** 0.7  
**Date:** September 19, 2026  
**Organization:** UNDECIDED  

## Purpose

Build a livable first-generation religious formation system while preserving explicit theological uncertainty and anti-coercion safeguards.

## Deliverables

- Master theology/practice/formation architecture
- Companion formation curriculum
- Prayer, gatherings & rites book
- Theological questions register
- Formation curriculum matrix
- Structured JSON architecture

## Status

Working draft for pilot practice; not a final creed, canon, liturgy, or ordination system.
