# The Way v0.7 - Theology, Practice & Formation Architecture

Date: September 19, 2026

## Deliverables

- way_theology_practice_formation_architecture_v0_7.docx / .pdf
- companion_formation_curriculum_v0_7.docx / .pdf
- prayer_gatherings_and_rites_book_v0_7.docx / .pdf
- way_theology_practice_formation_v0_7_source_pack.zip
- source/theological_questions_register_v0_7.csv
- source/formation_curriculum_map_v0_7.csv
- source/way_theology_practice_formation_v0_7.json

## Status

Working first-generation architecture for pilot use. It intentionally does not finalize a creed, canon, sexual/marriage theology, afterlife doctrine, ordination theology, or complete sacred calendar.
