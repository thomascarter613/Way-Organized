# The Way Community Architecture v0.6

**Date:** September 19, 2026  
**Organization:** UNDECIDED  
**Status:** Working religious-operational architecture; not yet fully constitutionalized

This v0.6 package converts the Native Religious Lexicon v0.5 into lived community architecture. It defines the human lifecycle of the Way, the Companion pathway, the Assembly, Houses of Prayer, gathering patterns, Rule of Life, ministry and commissioning, epistemic integrity, transmission, succession, and implementation forms.

It integrates with the prior Institutional Integrity & Anti-Coercion governance system. If a v0.6 practice conflicts with entrenched participant rights, safeguarding, financial controls, due process, or civil law, the stronger safeguard controls until the documents are formally reconciled.

The central design rule is: **the institution exists to serve the Way; the Way does not exist to preserve the institution.**
