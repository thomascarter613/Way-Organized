# The Way Community Architecture v0.6 - Release

Date: September 19, 2026
Status: Working religious-operational architecture for pilot use and later constitutional reconciliation.

## Primary deliverables
- way_community_architecture_v0_6.docx / .pdf - the 12-page system architecture covering the whole, human lifecycle, Companion pathway, Assembly, Houses of Prayer, gatherings, Rule of Life, ministry, epistemic integrity, succession, founder-exit test, and implementation sequence.
- way_community_forms_and_templates_v0_6.docx / .pdf - the 10-page implementation packet containing eight working forms plus the implementation checklist.
- way_community_architecture_v0_6_source_pack.zip - modular Markdown, JSON, CSV, DOCX source documents.

## Structured source highlights
- source/human_lifecycle_v0_6.csv
- source/way_community_architecture_v0_6.json
- source/13_forms_and_templates.md
- source/14_decision_register.md

## Design status
Adopted as working architecture: voluntary Companion identity, protected exit, Assembly/corporation distinction, House-of-Prayer model, five gathering categories, commissioning model, epistemic sequence, distributed succession, and founder-exit testing.

Provisional for pilot: exact Companion formation period, ceremonial form of commitment, Common Table as named practice, Elder role, religious councils, numeric House-recognition thresholds, and exact Rule-of-Life frequencies.

Reserved: formal canon, ordination theology, sacramental system, final doctrine of God/divine names, final soteriology/afterlife doctrine, full sacred calendar, and binding universal liturgy.
